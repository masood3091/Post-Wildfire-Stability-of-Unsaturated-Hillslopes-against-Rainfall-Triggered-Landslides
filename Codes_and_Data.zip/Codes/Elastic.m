function E = Elastic(EMd,EMs,Se,m)
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here
E = EMd+(EMs-EMd).*(Se).^m;
end

