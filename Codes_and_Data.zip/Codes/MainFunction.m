%%Root Properties
%Root Characteristics
string Root_Characteristic;
isittrue=0;
while isittrue==0
 Root_Characteristic=inputdlg("Want to consider root distribution (Enter 'Consider') or enter root reinforcement manually (Enter 'Manually')");
    if Root_Characteristic=="Consider" || Root_Characteristic=="Manually"
        isittrue=1;
    end
end
To=21.1;
alphaR=0.72;
Eo=696/2;
betaR=1;
L0=335;
gammaR=0.63;
Fo=22.1;
lambdaR=1.28;
Wo=36.2*10;
kappaR=0.289;
%Root Distribution Parameters
%Uniform
da=0.997;
db=2.84;
Fa=22;
Fb=83.8;
meanF_u=(1/(1+lambdaR))*((Fb^((1+lambdaR)/lambdaR))-(Fa^((1+lambdaR)/lambdaR)))/((Fb^(1/lambdaR))-(Fa^(1/lambdaR)));
%Weibull
md=3.38;
kd=2.15;
mF=2.64;
kF=58.7;
meanF_w=kF*(gammainc(0.5,(1/mF)+1,'upper'));
%Lognormal
mud=-6.28;  %ln
sigd=0.349; %ln
sigF=0.447; %ln
muF=3.90;   %ln
meanF_l=exp(((sigF^2)/2)+muF);
%%
%Root Reinforcement
if Root_Characteristic=="Consider"
    NR=100;  %number of roots in one square meter
    Max_Pr=Max_Root_Rein(kappaR,lambdaR,Wo,meanF_u,meanF_w,meanF_l,Fa,Fb,mF,kF,muF,sigF); %maximum root force for a single root (N)
    Total_Pr=Max_Pr*NR/1000; %maximum root force for a root bundle consisting of "NR" roots (kPa)
else
    Total_Pr=xlsread('RootReinforcement','Sheet1','B2:B1827');            %maximum root force for a root bundle consisting of "NR" roots (kPa)
    Total_Pr=Total_Pr.';
end
%% Slop, vegetation, and flow/discharge info
q=xlsread('Rainfall','San Gabriel Dam','J367:J2192'); %Infiltration(m/day)
T=xlsread('Transpiration_85','Sheet3','L367:L2192');  %Transpiration(m/day)
L=0.60;           %Total depth (m), prependicular to slope
L_1=0.15;         %Depth up in which there is no root (m), prependicular to slope
L_2=L-L_1;        %the root depth (m), prependicular to slope
htop=-5.0;        %unit (m)
gamaW=9.8;        %unit kn/m3
EMd=3000;        %Elastic Modulus dry state (kPa)
EMs=50;         %Elastic Modulus saturate state (kPa)
mu=0.4;           %Poisson's ratio
theta_r=0.0;
theta_s=0.4;
k_s = 0.4128;     %saturate hydraulic conductivity (m/sec)
alpha=2.0;        %related to air entery (1/m)
m=1.26;
Sink=T/L_2;       %Sink term
beta_degree=37.8;   %slope angle in degree
beta=beta_degree*pi/180;
t=length(q);
Water_Table=2.00; %Depth of water table below the bottom boundary
%%
%Soil mechanical Properties
phi_degree=22;         %Internal friction angle (degree) 
phi=pi*phi_degree/180;
c=0.05;                  %Cohesion (kPa)
gammaS=17.1;             %soil unite weight (kN/m3) 
%%
%Calculate Suction
string Flow_choice;
isittrue=0;
while isittrue==0
    Flow_choice=inputdlg("Choose the type of flow analysis, Choices are head/steady, head/transient, discharge/steady, or discharge/transient:",'s');
    if Flow_choice=="head/steady" || Flow_choice=="head/transient" || Flow_choice=="discharge/steady" || Flow_choice=="discharge/transient"
        isittrue=1;
    end
end
if Flow_choice=="head/steady"
    hM=headboundary_2Part_steady(L,L_1,htop,gamaW,EMd,EMs,mu,theta_r,theta_s,k_s,alpha,m,T,beta_degree);
elseif Flow_choice=="head/transient"
    hM=Flowhead_tran_unif_2_NF(L,L_1,htop,gamaW,EMd,EMs,mu,theta_r,theta_s,k_s,alpha,m,T,beta_degree,t);
elseif Flow_choice=="discharge/steady"
   [hM,hssM]=Flow_Discharge_tran_unif_2(L,L_1,htop,gamaW,EMd,EMs,mu,theta_r,theta_s,k_s,alpha,m,T,beta_degree,t,q);
    hM=hssM;
else
    hM=case_1_hM_try_F(L,L_1,Water_Table,gamaW,EMd,EMs,mu,theta_r,theta_s,k_s,alpha,m,beta_degree,t,q,Sink);
end
%%
%Calculate Suction Stress
SSM=zeros(size(hM));
for i=2:1:t+1
    SSM(:,i)=exp(alpha.*hM(:,i)).*(gamaW.*hM(:,i));
end
SSM(:,1)=hM(:,1);
%%
%Calculate Factor of Safety
string SuctionOrNot;
isittrue=0;
while isittrue==0
    SuctionOrNot=inputdlg("would you like to consider suction stress? 'yes' or 'no'",'s');
    if SuctionOrNot=="yes" || SuctionOrNot=="no"
        isittrue=1;
    end
end
string RootReinOrNot;
isittrue=0;
while isittrue==0
    RootReinOrNot=inputdlg("would you like to consider root reinfocement? 'yes' or 'no'",'s');
    if RootReinOrNot=="yes" || RootReinOrNot=="no"
        isittrue=1;
    end
end
if SuctionOrNot=="yes"
    k_Suc=1;
else
    k_Suc=0;
end
if RootReinOrNot=="yes"
    k_Root=1;
else
    k_Root=0;
end
count=1;
SF=zeros(size(SSM));
Rootcount=1;
for i=0.00:.01:L
    if i>=L_1
        IsThereRoot=1;
    else
        IsThereRoot=0;
    end
    RootRein(Rootcount,2:t+1)=Total_Pr(1,:).*IsThereRoot;
    RootRein(Rootcount,1)=i;
    Rootcount=Rootcount+1;
end
for z=0.00:0.01:L
    SF(count,2:end)=(c-k_Suc.*hM(count,2:end).*tan(phi).*gamaW+RootRein(count,2:end).*k_Root)/(gammaS*sin(beta)*(L-z))+tan(phi)/tan(beta);
    SF(count,1)=z;
    count=count+1;
end