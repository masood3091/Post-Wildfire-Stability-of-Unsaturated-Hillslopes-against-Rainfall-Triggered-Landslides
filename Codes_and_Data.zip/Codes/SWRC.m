function Se = SWRC(alpha,h)
%UNTITLED7 Summary of this function goes here
%   Detailed explanation goes here
Se = exp(alpha.*h);
end

