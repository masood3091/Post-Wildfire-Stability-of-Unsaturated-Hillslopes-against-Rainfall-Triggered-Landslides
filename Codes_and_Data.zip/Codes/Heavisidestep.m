function answer= Heavisidestep(t,i)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
if t>i
    answer=1;
else
    answer=0;
end
end

