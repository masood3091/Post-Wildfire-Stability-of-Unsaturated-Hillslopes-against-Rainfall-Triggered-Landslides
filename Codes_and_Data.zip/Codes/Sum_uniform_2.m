function [sum_1,sum_2,sum_3,sum_4,sum_5,sum_6,sum_7,sum_8,sum_9,sum_10,sum_11,sum_12] = Sum_uniform_2(L,L_1,alpha,z,c,beta,t)
quit=0;
flip=-1;
k=0;
sum_1=0;
while quit==0
    k=k+1;
    lambda_k=pi*k/L;
    mu_k=((alpha^2)*((cos(beta))^2)/4+lambda_k^2)/c;
    term=lambda_k/mu_k*exp(-1*mu_k*t);
    if  term<0.00000000000000000000000001
        quit=1;
    end
    sum_1=sum_1+flip*term*sin(lambda_k*z);
    flip=-flip;
end

quit=0;
flip=+1;
k=0;
sum_2=0;
while quit==0
    k=k+1;
    lambda_k=pi*k/L;
    mu_k=((alpha^2)*((cos(beta))^2)/4+lambda_k^2)/c;
    mu_k_2=(alpha^2)*((cos(beta))^2)+4*lambda_k^2;
    term=lambda_k/(mu_k_2)*exp(-1*mu_k*t);
    if  abs(term)<0.00000000000000000001
        quit=1;
    end
    sum_2=sum_2+flip*term*sin(lambda_k*z);
    flip=-flip;
end

quit=0;
k=0;
sum_3=0;
while quit==0
    k=k+1;
    lambda_k=pi*k/L;
    mu_k=((alpha^2)*((cos(beta))^2)/4+lambda_k^2)/c;
    mu_k_2=(alpha^2)*((cos(beta))^2)+4*lambda_k^2;
    term=(lambda_k)/(mu_k_2)*exp(-1*mu_k*t);
    if  term<0.00000000000000000001
        quit=1;
    end
    sum_3=sum_3+term*sin(lambda_k*z)*cos(lambda_k*L_1);
end

quit=0;
k=0;
sum_4=0;
while quit==0
    k=k+1;
    lambda_k=pi*k/L;
    mu_k=((alpha^2)*((cos(beta))^2)/4+lambda_k^2)/c;
    mu_k_2=(alpha^2)*((cos(beta))^2)+4*lambda_k^2;
    term=exp(-1*mu_k*t)/mu_k_2;
    if  term<0.00000000000000000001
        quit=1;
    end
    sum_4=sum_4+term*sin(lambda_k*z)*sin(lambda_k*L_1);
end
quit=0;
k=0;
sum_5=0;
while quit==0
    k=k+1;
    lambda_k=pi*k/L;
    mu_k=((alpha^2)*((cos(beta))^2)/4+lambda_k^2)/c;
    mu_k_2=(alpha^2)*((cos(beta))^2)+4*lambda_k^2;
    term=exp(-1*mu_k*t)/mu_k_2;
    if  term<0.00000000000000000001
        quit=1;
    end
    sum_5=sum_5+term*sin(lambda_k*z)*sin(lambda_k*L_1);
end
quit=0;
k=0;
sum_6=0;
while quit==0
    k=k+1;
    lambda_k=pi*k/L;
    mu_k=((alpha^2)*((cos(beta))^2)/4+lambda_k^2)/c;
    mu_k_2=(alpha^2)*((cos(beta))^2)+4*lambda_k^2;
    term=1*lambda_k/mu_k_2*exp(-1*mu_k*t);
    if  term<0.00000000000000000001
        quit=1;
    end
    sum_6=sum_6+term*sin(lambda_k*z)*cos(lambda_k*L_1);
    
end
quit=0;
flip=+1;
k=0;
sum_7=0;
while quit==0
    k=k+1;
    lambda_k=pi*k/L;
    mu_k=((alpha^2)*((cos(beta))^2)/4+lambda_k^2)/c;
    mu_k_2=(alpha^2)*((cos(beta))^2)+4*lambda_k^2;
    term=lambda_k/mu_k_2*exp(-1*mu_k*t);
    if  term<0.00000000000000000001
        quit=1;
    end
    sum_7=sum_7+flip*term*sin(lambda_k*z);
    flip=-flip;
end
quit=0;
flip=-1;
k=0;
sum_8=0;
while quit==0
    k=k+1;
    lambda_k=pi*k/L;
    mu_k=((alpha^2)*((cos(beta))^2)/4+lambda_k^2)/c;
    mu_k_2=(alpha^2)*((cos(beta))^2)+4*lambda_k^2;
    term=lambda_k/(mu_k_2^2)*exp(-1*mu_k*t);
    if  term<0.00000000000000000001
        quit=1;
    end
    sum_8=sum_8+flip*term*sin(lambda_k*z);
    flip=-flip;
end
quit=0;
flip=-1;
k=0;
sum_9=0;
while quit==0
    k=k+1;
    lambda_k=pi*k/L;
    mu_k=((alpha^2)*((cos(beta))^2)/4+lambda_k^2)/c;
    mu_k_2=(alpha^2)*((cos(beta))^2)+4*lambda_k^2;
    term=(lambda_k^3)/(mu_k_2^2)*exp(-1*mu_k*t);
    if  term<0.00000000000000000001
        quit=1;
    end
    sum_9=sum_9+flip*term*sin(lambda_k*z);
    flip=-flip;
end
quit=0;
k=0;
sum_10=0;
while quit==0
    k=k+1;
    lambda_k=pi*k/L;
    mu_k=((alpha^2)*((cos(beta))^2)/4+lambda_k^2)/c;
    mu_k_2=(alpha^2)*((cos(beta))^2)+4*lambda_k^2;
    term=1*lambda_k/(mu_k_2^2)*exp(-1*mu_k*t);
    if  term<0.00000000000000000001
        quit=1;
    end
    sum_10=sum_10+term*sin(lambda_k*z)*cos(lambda_k*L_1);
end
quit=0;
k=0;
sum_11=0;
while quit==0
    k=k+1;
    lambda_k=pi*k/L;
    mu_k=((alpha^2)*((cos(beta))^2)/4+lambda_k^2)/c;
    mu_k_2=(alpha^2)*((cos(beta))^2)+4*lambda_k^2;
    term=exp(-1*mu_k*t)/(mu_k_2^2);
    if  term<0.00000000000000000001
        quit=1;
    end
    sum_11=sum_11+term*sin(lambda_k*z)*sin(lambda_k*L_1);
end
quit=0;
k=0;
sum_12=0;
while quit==0
    k=k+1;
    lambda_k=pi*k/L;
    mu_k=((alpha^2)*((cos(beta))^2)/4+lambda_k^2)/c;
    mu_k_2=(alpha^2)*((cos(beta))^2)+4*lambda_k^2;
    term=1*(lambda_k^2)/(mu_k_2^2)*exp(-1*mu_k*t);
    if  term<0.000000000000000001
        quit=1;
    end
    sum_12=sum_12+term*sin(lambda_k*z)*sin(lambda_k*L_1);
end
end


