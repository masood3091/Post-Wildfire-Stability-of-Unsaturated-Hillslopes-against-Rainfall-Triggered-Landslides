function hssM=headboundary_2Part_steady(L,L_1,htop,gamaW,EMd,EMs,mu,theta_r,theta_s,k_s,alpha,m,T,beta_degree)
%L=10;          %Total depth (m)
%L_1=0;         %Depth up in which there is no root (m)
L_2=L-L_1;     %the root depth (m)
%htop=-5.0;     %unit (m)
%gamaW=9.8;     %unit kn/m3
%EMd=10000;     %Elastic Modulus dry state (kPa)
%EMs=1000;      %Elastic Modulus saturate state (kPa)
%mu=0.4;        %Poisson's ratio
%theta_r=0.0;
%theta_s=0.4;
%k_s = 1e-6;    %saturate hydraulic conductivity (m/sec)
%alpha=0.001;   %related to air entery (1/m)
%m=1;
%T=7.64e-7;     %Transpiration rate (m/sec)
S=T/L;         %Sink term
%beta_degree=30; %slope angle in degree
beta=beta_degree*pi/180;
%%
%Steady State
r=1;
c_2=(exp(alpha.*htop)-exp(-1*alpha*L*cos(beta))-S*L_2/k_s/cos(beta)-exp(-1*alpha*L_2*cos(beta))*S/alpha/k_s/((cos(beta))^2)+...
    S/alpha/k_s/((cos(beta))^2))/(1-exp(-1*alpha*L*cos(beta)));
for z=0:0.01:L
    if z>=L_1
         hss_bar=c_2*(1-exp(-1*alpha*z*cos(beta)))+S*(z-L_1)/k_s/cos(beta)...
         +exp(-1*alpha*cos(beta)*(z-L_1))*S/alpha/k_s/((cos(beta))^2)-S/alpha/k_s/((cos(beta))^2);
    else
        hss_bar=c_2*(1-exp(-1*alpha*z*cos(beta)));
    end
 hss=(1/alpha)*log(hss_bar+exp(alpha*z*-1*cos(beta)));
 hss_barM(r,1)=hss_bar; %putting the values for different depth in a matrix
 hssM(r,1)=hss;         %putting the values for different depth in a matrix
 hssM(r,2)=z;           %corresponding depths
 r=r+1;
end
end