function [hM,hssM]=Flow_Discharge_tran_unif_2(L,L_1,htop,gamaW,EMd,EMs,mu,theta_r,theta_s,k_s,alpha,m,T,beta_degree,t,q)
%Written by Masood Abdollahi
%L=10;           %unit m
%L_1=0;         %Depth up in which there is no root (m)
%gamaW=9.8;     %unit kn/m3
%EMd=10000;     %Elastic Modulus dry state (kPa)
%EMs=1000;      %Elastic Modulus saturate state (kPa)
%mu=0.4;        %Poisson's ratio
%theta_r=0.00;
%theta_s=0.40;
%k_s = 1e-6;    %saturate hydraulic conductivity (m/sec)
%alpha=0.001;   %related to air entery (1/m)
%m=1;
%t=0.5*24*3600; %time in second
%q=-0.9*1e-6;   %precipitation rate
%T=7.64e-7;     %Transpiration rate (m/sec)
S=T/L;         %Sink term
%beta_degree=0; %slope angle in degree
beta=beta_degree*pi/180;
isittrue=0;
while isittrue==0
    analysmode=inputdlg("enter analysmode, either coupled or uncoupled",'s');
    if analysmode=="coupled" || analysmode=="uncoupled"
        isittrue=1;
    end
end
%%
%Transient
epsnon=0.00001;
r=-1*q/k_s;

htop1=-epsnon;
htop2=epsnon-L;
z=L-epsnon;
h_l_eps_1=Flowhead_tran_unif_2(L,L_1,gamaW,EMd,EMs,mu,theta_r,theta_s,k_s,alpha,m,htop1,z,t,S,beta,analysmode);
r_1=exp(alpha/2*(htop1+h_l_eps_1))*((htop1-h_l_eps_1)/epsnon+1);
h_l_eps_2=Flowhead_tran_unif_2(L,L_1,gamaW,EMd,EMs,mu,theta_r,theta_s,k_s,alpha,m,htop2,z,t,S,beta,analysmode);
r_2=exp(alpha/2*(htop2+h_l_eps_2))*((htop2-h_l_eps_2)/epsnon+1);
while 1
    htop=(htop2-htop1)/(r_2-r_1)*(r-r_1)+htop1;
    h_l_eps=Flowhead_tran_unif_2(L,L_1,gamaW,EMd,EMs,mu,theta_r,theta_s,k_s,alpha,m,htop,z,t,S,beta,analysmode);
    r_test=exp(alpha/2*(htop+h_l_eps))*((htop-h_l_eps)/epsnon+1);
    if r_test<(r-epsnon)
        r_2=r_test;
        htop2=htop;
    end
    if r_test>(r+epsnon)
        r_1=r_test;
        htop1=htop;
    end
    if abs(r_test-r)<=epsnon
        break
    end    
end
counter_1=1;
for z=0:.01:L
    hM(counter_1,1)=Flowhead_tran_unif_2(L,L_1,gamaW,EMd,EMs,mu,theta_r,theta_s,k_s,alpha,m,htop,z,t,S,beta,analysmode);
    hM(counter_1,2)=z;
    counter_1=counter_1+1;
end
    
%%
%Steady State
counter_2=1;
c_2=(r-S*L/k_s+S*L_1/k_s);
for z=0:0.01:L
if z>=L_1
        hss_bar=c_2*(1-exp(-1*alpha*z*cos(beta)))+S*(z-L_1)/k_s/cos(beta)...
         +exp(-1*alpha*cos(beta)*(z-L_1))*S/alpha/k_s/((cos(beta))^2)-S/alpha/k_s/((cos(beta))^2);
    else
        hss_bar=c_2*(1-exp(-1*alpha*z*cos(beta)));
end
    hss=1/alpha*log(hss_bar+exp(-1*alpha*z*cos(beta)));
    hssM(counter_2,1)=hss;
    hssM(counter_2,2)=z;
    counter_2=counter_2+1;
end  
end