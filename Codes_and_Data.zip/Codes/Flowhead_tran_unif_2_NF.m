function hM=Flowhead_tran_unif_2_NF(L,L_1,htop,gamaW,EMd,EMs,mu,theta_r,theta_s,k_s,alpha,m,T,beta_degree,t)
%written by Masood Abdollahi
%L=10;          %unit m
%L_1=0;         %Depth up in which there is no root (m)
L_2=L-L_1;     %the root depth (m)
%htop=-5.0;     %unit m
%gamaW=9.8;     %unit kn/m3
%EMd=10000;     %Elastic Modulus dry state (kPa)
%EMs=1000;      %Elastic Modulus saturate state (kPa)
%mu=0.4;        %Poisson's ratio
%theta_r=0.0;
%theta_s=0.4;
%k_s = 1e-6;    %saturate hydraulic conductivity (m/sec)
%alpha=0.001;   %related to air entery (1/m)
%m=1;
%T=7.64e-7;     %Transpiration rate (m/sec)
S=T/L;         %Sink term
%beta_degree=0; %slope angle in degree
beta=beta_degree*pi/180;
%%
%Steady State
r=1;
c_2=(exp(alpha.*htop)-exp(-1*alpha*L*cos(beta))-S*L_2/k_s/cos(beta)-exp(-1*alpha*L_2*cos(beta))*S/alpha/k_s/((cos(beta))^2)+...
    S/alpha/k_s/((cos(beta))^2))/(1-exp(-1*alpha*L*cos(beta)));
for z=0:0.01:L
    if z>=L_1
         hss_bar=c_2*(1-exp(-1*alpha*z*cos(beta)))+S*(z-L_1)/k_s/cos(beta)...
         +exp(-1*alpha*cos(beta)*(z-L_1))*S/alpha/k_s/((cos(beta))^2)-S/alpha/k_s/((cos(beta))^2);
    else
        hss_bar=c_2*(1-exp(-1*alpha*z*cos(beta)));
    end
 hss=(1/alpha)*log(hss_bar+exp(alpha*z*-1*cos(beta)));
 hss_barM(r,1)=hss_bar; %putting the values for different depth in a matrix
 hssM(r,1)=hss;         %putting the values for different depth in a matrix
 hssM(r,2)=z;           %corresponding depths
 r=r+1;
end

%%
%Transient head boundary at top
gamma_1=(exp(alpha.*htop)-exp(-1*alpha*L*cos(beta))-S*L_2/k_s/cos(beta)-exp(-1*alpha*L_2*cos(beta))*S/alpha/k_s/((cos(beta))^2)+...
    S/alpha/k_s/((cos(beta))^2))/(1-exp(-1*alpha*L*cos(beta)));
gamma_2=S/k_s/cos(beta);
gamma_3=S/alpha/k_s/((cos(beta))^2);
r=1;
isittrue=0;
while isittrue==0
    analysmode=inputdlg("enter analysmode, either coupled or uncoupled",'s');
    if analysmode=="coupled" || analysmode=="uncoupled"
        isittrue=1;
    end
end
%t=0.01*3600*24;
if analysmode=="coupled"
    for z=0:0.01:L
        quit=0;
        h_initial=0;
        while quit==0
            Se=SWRC(alpha,h_initial);
            E=Elastic(EMd,EMs,Se,m);
            c=(1/k_s)*(Se*gamaW*(1+mu)*(1-2*mu)/E/(1-mu)+alpha*(theta_s-theta_r));
            [sum_1,sum_2,sum_3,sum_4,sum_5,sum_6,sum_7,sum_8,sum_9,sum_10,sum_11,sum_12]=Sum_uniform_2(L,L_1,alpha,z,c,beta,t);
            h_hat=exp(-1*alpha*cos(beta)*z/2)*4*gamma_1/L/c*sinh(alpha*cos(beta)/2*L)*sum_1...
                +exp(-1*alpha*cos(beta)*z/2)*2*gamma_3/L*(4*exp(alpha*cos(beta)/2*L)*sum_2+4*exp(alpha*cos(beta)*L_1/2)*sum_3-2*exp(alpha*cos(beta)/2*L_1)*alpha*cos(beta)*sum_4)...
                +exp(-1*alpha*cos(beta)*z/2)*-1*2*gamma_3/L*(2*alpha*cos(beta)*exp(alpha*L_1*cos(beta)/2)*sum_5+4*exp(alpha*L_1*cos(beta)/2)*sum_6+...
                4*exp(alpha*cos(beta)*(L_1-L/2))*sum_7)+...
                exp(-1*alpha*cos(beta)*z/2)*-1*2*gamma_2/L*(16*alpha*cos(beta)*exp(alpha*cos(beta)/2*L)*sum_8-4*L_2*exp(alpha*cos(beta)*L/2)*(alpha^2)*((cos(beta))^2)*sum_8-...
                16*L_2*exp(alpha*cos(beta)/2*L)*sum_9-16*cos(beta)*alpha*exp(alpha*cos(beta)/2*L_1)*sum_10+...
                4*(alpha^2)*((cos(beta))^2)*exp(alpha*cos(beta)/2*L_1)*sum_11-16*exp(alpha*cos(beta)*L_1/2)*sum_12);
            h_hatM(r,1)=h_hat; %putting the values for different depth in a matrix
            h_hatM(r,2)=z;     %corresponding depths 
            h_bar=h_hat+hss_barM(r,1);
            h=1/alpha*log(h_bar+exp(-1*cos(beta)*alpha*z));
            if abs(h-h_initial)<0.0001
                quit=1;
            else
                h_initial=h;
            end
        end
        hM(r,1)=h; %putting the values for different depth in a matrix
        hM(r,2)=z; %correspondind depths
        r=r+1;
    end
else
    for z=0:0.01:L
        c=alpha/k_s*(theta_s-theta_r);
        [sum_1,sum_2,sum_3,sum_4,sum_5,sum_6,sum_7,sum_8,sum_9,sum_10,sum_11,sum_12]=Sum_uniform_2(L,L_1,alpha,z,c,beta,t);
        h_hat=exp(-1*alpha*cos(beta)*z/2)*4*gamma_1/L/c*sinh(alpha*cos(beta)/2*L)*sum_1...
            +exp(-1*alpha*cos(beta)*z/2)*2*gamma_3/L*(4*exp(alpha*cos(beta)/2*L)*sum_2+4*exp(alpha*cos(beta)*L_1/2)*sum_3-2*exp(alpha*cos(beta)/2*L_1)*alpha*cos(beta)*sum_4)...
            +exp(-1*alpha*cos(beta)*z/2)*-1*2*gamma_3/L*(2*alpha*cos(beta)*exp(alpha*L_1*cos(beta)/2)*sum_5+4*exp(alpha*L_1*cos(beta)/2)*sum_6+...
            4*exp(alpha*cos(beta)*(L_1-L/2))*sum_7)+...
            exp(-1*alpha*cos(beta)*z/2)*-1*2*gamma_2/L*(16*alpha*cos(beta)*exp(alpha*cos(beta)/2*L)*sum_8-4*L_2*exp(alpha*cos(beta)*L/2)*(alpha^2)*((cos(beta))^2)*sum_8-...
            16*L_2*exp(alpha*cos(beta)/2*L)*sum_9-16*cos(beta)*alpha*exp(alpha*cos(beta)/2*L_1)*sum_10+...
            4*(alpha^2)*((cos(beta))^2)*exp(alpha*cos(beta)/2*L_1)*sum_11-16*exp(alpha*cos(beta)*L_1/2)*sum_12);
        h_hatM(r,1)=h_hat; %putting the values for different depth in a matrix
        h_hatM(r,2)=z;     %corresponding depths 
        h_bar=h_hat+hss_barM(r,1);
        h=1/alpha*log(h_bar+exp(-1*cos(beta)*alpha*z));
        hM(r,1)=h; %putting the values for different depth in a matrix
        hM(r,2)=z; %correspondind depths
        r=r+1;        
    end  
end
end   
